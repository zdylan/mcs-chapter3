CREATE VIEW sys.schema_auto_increment_columns AS
  SELECT
    `columns`.`TABLE_SCHEMA`                                                                           AS `TABLE_SCHEMA`,
    `columns`.`TABLE_NAME`                                                                             AS `TABLE_NAME`,
    `columns`.`COLUMN_NAME`                                                                            AS `COLUMN_NAME`,
    `columns`.`DATA_TYPE`                                                                              AS `DATA_TYPE`,
    `columns`.`COLUMN_TYPE`                                                                            AS `COLUMN_TYPE`,
    (locate('unsigned', `columns`.`COLUMN_TYPE`) = 0)                                                  AS `is_signed`,
    (locate('unsigned', `columns`.`COLUMN_TYPE`) > 0)                                                  AS `is_unsigned`,
    ((CASE `columns`.`DATA_TYPE`
      WHEN 'tinyint'
        THEN 255
      WHEN 'smallint'
        THEN 65535
      WHEN 'mediumint'
        THEN 16777215
      WHEN 'int'
        THEN 4294967295
      WHEN 'bigint'
        THEN 18446744073709551615 END) >> if((locate('unsigned', `columns`.`COLUMN_TYPE`) > 0), 0, 1)) AS `max_value`,
    `tables`.`AUTO_INCREMENT`                                                                          AS `AUTO_INCREMENT`,
    (`tables`.`AUTO_INCREMENT` / ((CASE `columns`.`DATA_TYPE`
                                   WHEN 'tinyint'
                                     THEN 255
                                   WHEN 'smallint'
                                     THEN 65535
                                   WHEN 'mediumint'
                                     THEN 16777215
                                   WHEN 'int'
                                     THEN 4294967295
                                   WHEN 'bigint'
                                     THEN 18446744073709551615 END) >>
                                  if((locate('unsigned', `columns`.`COLUMN_TYPE`) > 0), 0,
                                     1)))                                                              AS `auto_increment_ratio`
  FROM (`information_schema`.`COLUMNS`
    JOIN `information_schema`.`TABLES`
      ON (((`columns`.`TABLE_SCHEMA` = `tables`.`TABLE_SCHEMA`) AND (`columns`.`TABLE_NAME` = `tables`.`TABLE_NAME`))))
  WHERE ((`columns`.`TABLE_SCHEMA` NOT IN ('mysql', 'sys', 'INFORMATION_SCHEMA', 'performance_schema')) AND
         (`tables`.`TABLE_TYPE` = 'BASE TABLE') AND (`columns`.`EXTRA` = 'auto_increment'))
  ORDER BY (`tables`.`AUTO_INCREMENT` / ((CASE `columns`.`DATA_TYPE`
                                          WHEN 'tinyint'
                                            THEN 255
                                          WHEN 'smallint'
                                            THEN 65535
                                          WHEN 'mediumint'
                                            THEN 16777215
                                          WHEN 'int'
                                            THEN 4294967295
                                          WHEN 'bigint'
                                            THEN 18446744073709551615 END) >>
                                         if((locate('unsigned', `columns`.`COLUMN_TYPE`) > 0), 0, 1))) DESC,
    ((CASE `columns`.`DATA_TYPE`
      WHEN 'tinyint'
        THEN 255
      WHEN 'smallint'
        THEN 65535
      WHEN 'mediumint'
        THEN 16777215
      WHEN 'int'
        THEN 4294967295
      WHEN 'bigint'
        THEN 18446744073709551615 END) >> if((locate('unsigned', `columns`.`COLUMN_TYPE`) > 0), 0, 1));
